
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Favicon icon -->
  <link rel="icon" href="<?php echo e(asset('assets/images/fav.png')); ?>" type="image/x-icon">
  <!-- Google font-->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
  <!-- waves.css -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/pages/waves/css/waves.min.css')); ?>" type="text/css" media="all">
  <!-- Required Fremwork -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap/css/bootstrap.min.css')); ?>">
  <!-- waves.css -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/pages/waves/css/waves.min.css')); ?>" type="text/css" media="all">
  <!-- themify icon -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/icon/themify-icons/themify-icons.css')); ?>">
  <!-- font-awesome-n -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/font-awesome-n.min.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
  <!-- scrollbar.css -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/jquery.mCustomScrollbar.css')); ?>">
  <!-- Style.css -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">
  <script src="https://cdn.ckeditor.com/4.19.0/standard/ckeditor.js"></script><?php /**PATH D:\TheLegato\resources\views/headtags.blade.php ENDPATH**/ ?>